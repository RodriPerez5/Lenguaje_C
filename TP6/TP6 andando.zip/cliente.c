#include "header.h"
void cliente(pid_t pidB, char* texto, int largo) {
								int sd; //socket descriptor
								en_ejecucion = 1;
								rolProceso = CLIENTE;
								printf("Soy cliente %d\n", pidB);
								//Creamos el socket:
								//	AF_INET: Familia de protocolos TCP/IP
								//	SOCK_STREAM: Servicio orientado a la conexion (normalmente protocolo TCP)
								sd = socket(AF_INET, SOCK_STREAM, 0);
								if (sd < 0) {
																perror("Error al crear socket (cliente)");
																abort();
								}

								//Creamos la configuracion de direccion para el socket
								struct sockaddr_in direccionSocket; //Estructura para configurar el socket
								memset(&direccionSocket, 0, sizeof(direccionSocket)); //Utilizamos memset para inicializar a 0 todos los bytes de la estructura de configuracion del socket
								direccionSocket.sin_family = AF_INET; //Familia de direcciones de TCP/IP
								inet_aton("127.0.0.1", &(direccionSocket.sin_addr)); //Especificamos la direccion IP al que se conectara el socket, y la convertimos al formato de la red
								direccionSocket.sin_port = htons(PUERTO_SERVER); //Especificamos el puerto TCP al que se conectara el socket, y lo convertimos al byte order de la red

								//Establecemos conexion con el server
								int conectado;
								do {
																sleep(1);
																conectado = connect(sd, (struct sockaddr *) &direccionSocket, sizeof(direccionSocket));
								} while (conectado < 0);

								//char buffer_lectura[10];
								char buffer_envio[100];
								sprintf(buffer_envio, "%s", texto);

								printf("Cliente envia: %s", buffer_envio);
								send(sd, buffer_envio, sizeof(buffer_envio), 0);
								getchar();
								close(sd);
}
