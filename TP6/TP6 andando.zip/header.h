#ifndef HEADER_H
#define HEADER_H

#include <pthread.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>		//Sockets
#include <arpa/inet.h>		//Sockets
#include <unistd.h> 	 	//Biblioteca para multiprocessing (fork)
#include <signal.h> 		//Biblioteca para enviar senales a los procesos (kill)
#include <bits/signum.h> 	//Biblioteca conconstantes para los tipos de senales
#include <sys/wait.h>
#include <string.h>			//memset


typedef int boolean;
#define TRUE 1
#define FALSE 0
boolean en_ejecucion;
#define MAX_LARGO_COLA 100
#define PUERTO_SERVER 3302

#define SERVER 0
#define CLIENTE 1
int rolProceso;
int sd; //socket descriptor
int sd_aceptado;
int c;
char buffer_lectura[100];
char *datos[100];

pid_t crear_proceso();
char *leer_archivo(const char *filename);
void servidor(pid_t);
void cliente(pid_t pidB, char* texto, int largo);
void* bloques();
void *save_thread(void* arg);
void *print_thread(void* arg);

//Mutex para acceder al buffer (para evitar problemas de concurrencia cuando multiples threads quieren acceder simultaneamente al buffer)
extern pthread_mutex_t mutex_datos;

//Variable de condicion para indicarle al lector que hay informacion en el buffer
extern pthread_cond_t hay_datos;


#endif
