#include "header.h"

void servidor(pid_t pidB) {
								en_ejecucion = 1;

								rolProceso = SERVER;
								printf("Soy servidor %d\n", pidB);
								//Creamos el socket:
								//	AF_INET: Familia de protocolos TCP/IP
								//	SOCK_STREAM: Servicio orientado a la conexion (normalmente protocolo TCP)
								sd = socket(AF_INET, SOCK_STREAM, 0);
								if (sd < 0) {
																perror("Error al crear socket (servidor)");
																abort();
																printf("Soy cliente %d\n", pidB);
								}

								//Creamos la configuracion de direccion para el socket
								struct sockaddr_in direccionSocket; //Estructura para configurar el socket
								memset(&direccionSocket, 0, sizeof(direccionSocket)); //Utilizamos memset para inicializar a 0 todos los bytes de la estructura de configuracion del socket
								direccionSocket.sin_family = AF_INET; //Familia de direcciones de TCP/IP
								inet_aton("127.0.0.1", &(direccionSocket.sin_addr)); //Especificamos la direccion IP al que se conectara el socket, y la convertimos al formato de la red
								direccionSocket.sin_port = htons(PUERTO_SERVER); //Especificamos el puerto TCP al que se conectara el socket, y lo convertimos al byte order de la red

								//Enlazamos el socket con la direccion local

								if (bind(sd, (struct sockaddr *) &direccionSocket, sizeof(direccionSocket)) < 0) {
																perror("Error al enlazar socket al puerto (servidor)");
																printf("soy: %d\n", pidB);
																abort();
								}

								//Configuramos el socket para que escuche conexiones, y configuramos una cantidad maxima MAX_LARGO_COLA de conexiones que podemos poner en la cola
								listen(sd, MAX_LARGO_COLA);

								//Creamos las variables requeridas para esperar una conexion
								struct sockaddr_in direccionSocketCliente;
								socklen_t longitudDireccionCliente;

								//El proceso se bloquea esperando una conexion
								sd_aceptado = accept(sd, (struct sockaddr *) &direccionSocketCliente, &longitudDireccionCliente);

								pthread_t t1;
								pthread_t t2;
								pthread_t t3;
								pthread_t t4;
								if (pthread_create(&t1, NULL, bloques, NULL)) {
																printf("Error al crear el t1.\n");
																abort(); //Sale del programa y realiza un volcado del nucleo (muestra el estado completo del proceso con sus variables, instrucciones, etc.
								}
								if (pthread_create(&t2, NULL, print_thread, NULL)) {
																printf("Error al crear el t2.\n");
																abort(); //Sale del programa y realiza un volcado del nucleo (muestra el estado completo del proceso con sus variables, instrucciones, etc.
								}
								if (pthread_create(&t3, NULL, save_thread, NULL)) {
																printf("Error al crear el t3.\n");
																abort(); //Sale del programa y realiza un volcado del nucleo (muestra el estado completo del proceso con sus variables, instrucciones, etc.
								}

								// Esperamos a que termine el hilo secundario, para evitar que quede colgado como un zombie thread
								pthread_join(t3, NULL);
								pthread_join(t2, NULL);
								pthread_join(t1, NULL);
}
