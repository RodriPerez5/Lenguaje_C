#include "header.h"
#include "signal.h"
#include <bits/signum.h>  //Biblioteca conconstantes para los tipos de senales

void manejador_signals(int signal_type)
{
								printf("Terminando proceso\n");
								en_ejecucion = FALSE;
}


//Mutex para acceder al buffer (para evitar problemas de concurrencia cuando multiples threads quieren acceder simultaneamente al buffer)
pthread_mutex_t mutex_datos=PTHREAD_MUTEX_INITIALIZER;

//Variable de condicion para indicarle al lector que hay informacion en el buffer
pthread_cond_t hay_datos=PTHREAD_COND_INITIALIZER;

int main() {
								pthread_mutex_t test;
								pid_t pidB;
								pidB = crear_proceso();
								signal(SIGTERM, manejador_signals);

								switch (pidB) {
								case -1: // Si pid es -1 quiere decir que ha habido un error
																perror("No se ha podido crear el proceso hijo\n");
																break;
								case 0: // Cuando pid es cero quiere decir que es el proceso hijo
																printf("Soy el hijo B %d\n", pidB);
																printf("Puerto: %d\n", PUERTO_SERVER);
																servidor(pidB);
																break;
								default: // Cuando es distinto de cero es el padre
																printf("Soy el padre %d\n", pidB);
																char mensaje[] = ("mensaje.txt");
																char *texto = leer_archivo(mensaje);
																printf( " %s\n",texto );
																int largo=strlen(texto); //queria enviar el largo del texto para asignar memoria dinamicamente pero no pude enviar un struct
																printf("El largo del texto es de %d bytes\n",largo);
																cliente(pidB, texto, largo);
																kill(pidB, SIGTERM);
																break;
								}

								return 0;
}
