#include "header.h"
/*
   void *leer_archivo(void *arg){
        FILE* mensaje;
        mensaje = fopen("mensaje.txt", "r");
        if(mensaje==NULL) printf("no hay archivo\n");
        char texto[80];
        fscanf(mensaje," %[^\n]",&texto);
        printf("El archivo dice: %s\n", texto);
   }
 */
char *leer_archivo(const char *filename)
{
        long int size = 0;
        FILE *file = fopen(filename, "r");

        if(!file) {
                fputs("File error.\n", stderr);
                return NULL;
        }

        fseek(file, 0, SEEK_END);
        size = ftell(file);
        rewind(file);

        char *texto = (char *) malloc(size+1);
        texto[size]='\0';

        if(!texto) {
                fputs("Memory error.\n", stderr);
                return NULL;
        }
        //size_t Nbloques = fread(texto, 10, size/10, file);
        if(fread(texto, 1, size, file) != size) {
                fputs("Read error.\n", stderr);
                return NULL;
        }
        //printf("hay bloques: %d \n",Nbloques );
        fclose(file);
        return texto;
}
/*
   int main(int argc, char **argv)
   {
    if(argc < 2) {
        fputs("Need an argument.\n", stderr);
        return -1;
    }

    char *result = read_from_file(argv[1]);

    if(!result) return -1;

    fputs(result, stdout);
    free(result);

    return 0;
   }
 */
