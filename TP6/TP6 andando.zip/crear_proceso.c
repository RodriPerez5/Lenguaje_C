#include"header.h"
#include <sys/types.h>

pid_t crear_proceso() {
	pid_t pid;
	pid = fork();
	return pid;
}
