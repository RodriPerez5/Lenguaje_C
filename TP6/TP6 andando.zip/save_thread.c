#include "header.h"
void *save_thread(void* arg){
        char *mensaje2;
        FILE *file = fopen("mensaje2.txt", "r+");// lectura, escritura.

        if(!file) {
                fputs("File error.\n", stderr);

        }
        //fputs( buffer_lectura, file );
        if(fputs( buffer_lectura, file )<0) {
                fputs("Writing error.\n", stderr); //Si no le doy permiso de escritura, da este error.
        }
        else{
                printf("La escritura se realizo correctamente.\n");
        }

        return NULL;
        fclose(file);
}
