#include "header.h"
void *print_thread(void* arg){
        int i=0;
        if (c > 0) {
                while(en_ejecucion) {
                        if(i==0) {
                                printf("Servidor t2  recibio: '%s'\n", buffer_lectura);
                        }
                        i++;
                        sleep(5);
                }
        }
        return NULL;
}
