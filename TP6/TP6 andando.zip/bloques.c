#include "header.h"

void *bloques(void* arg) {

								while (en_ejecucion) {
																//Ahora intentamos leer los bytes transferidos. El proceso se bloquea si no hay nada que
																c = recv(sd_aceptado, buffer_lectura, sizeof(buffer_lectura), 0);

																//Esta verificacion solo se necesita para minimizar mensajes y ejecucion si se modifica la bandera en la mitad del bucle
																if (c > 0) {

																								//printf("Servidor recibio %d: '%s'\n", c, buffer_lectura);
																								printf("Servidor t1 recibio %d\n", c);


																}


																sleep(1);
																c=0;


								}

								//Cerramos el nuevo socket creado con accept
								close(sd_aceptado);

								//Cerramos el socket original
								close(sd);
								return NULL;
}
